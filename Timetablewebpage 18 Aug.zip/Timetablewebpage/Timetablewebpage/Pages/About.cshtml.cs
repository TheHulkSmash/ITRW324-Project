﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using System;

namespace Timetablewebpage.Pages
{
    public class AboutModel : PageModel
    {
        public string Message { get; set; }

        public void OnGet()
        {
            
        }
    }
}
