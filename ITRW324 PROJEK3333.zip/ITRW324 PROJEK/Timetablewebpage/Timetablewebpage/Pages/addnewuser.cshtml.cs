using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Timetablewebpage.Pages
{
    public class addnewuserModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}